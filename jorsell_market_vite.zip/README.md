Jorsell Market - Vite Modular (jorsell_market_vite)
==================================================

Cara menjalankan:
1. Salin file .env.example menjadi .env dan masukkan kredensial Supabase:
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key

2. Install & jalankan:
   npm install
   npm run dev

Struktur proyek:
jorsell_market_vite/
├── index.html
├── assets/
└── js/
├── supabase.js
├── main.js
├── page.js
├── auth.js
├── chat.js
├── profile.js
├── products.js
└── finance.js

Catatan:
- Pastikan tabel Supabase (products, conversations, messages, carts, affiliates, withdraws, orders, order-items) sesuai.
- File gambar adalah placeholder; ganti dengan aset aslimu di folder assets/.
