import { sb } from './supabase.js';
import * as auth from './auth.js';
import * as main from './main.js';

export let currentChatSubscription = null;
export let currentConversationId = null;
export let currentChatListSubscription = null;

function escapeHTML(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

export function unsubscribeFromChatList() {
    if (currentChatListSubscription) {
        try { sb.removeChannel(currentChatListSubscription); } catch(e){ console.warn('removeChannel', e); }
        currentChatListSubscription = null;
    }
}
export function unsubscribeFromChat() {
  if (currentChatSubscription) {
    try { sb.removeChannel(currentChatSubscription); } catch(e){ console.warn('removeChannel', e); }
    currentChatSubscription = null;
  }
}

export function subscribeToChatList() {
  unsubscribeFromChatList();
  if (!auth.currentUser || !document.getElementById('chat-list-container')) return;
  const currentUserId = auth.currentUser.id;
  currentChatListSubscription = sb
    .channel('chat-list-updates')
    .on('postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'conversations',
        filter: `buyer_id=eq.${currentUserId}|seller_id=eq.${currentUserId}`,
      },
      payload => {
        if (document.getElementById('chat-page')?.classList.contains('active')) {
          loadChatListPage();
        }
      })
    .subscribe();
}

export async function loadChatListPage() {
  const container = document.getElementById('chat-list-container');
  if (!container || !auth.currentUser) return;
  subscribeToChatList();
  container.innerHTML = '<div class="small">Memuat percakapan...</div>';
  try {
    const { data, error } = await sb
      .from("conversations")
      .select(`id,buyer_id,seller_id,buyer:users!conversations_buyer_id_fkey(full_name, avatar_url, email), seller:users!conversations_seller_id_fkey(full_name, avatar_url, email), messages(content, created_at)`)
      .or(`buyer_id.eq.${auth.currentUser.id},seller_id.eq.${auth.currentUser.id}`)
      .order("updated_at", { ascending: false });

    if (error) throw error;
    if (!data || !data.length) {
      container.innerHTML = "<div class='small'>Belum ada percakapan.</div>";
      return;
    }
    container.innerHTML = "";
    data.forEach((conv) => {
      const lastMsg = conv.messages?.sort((a,b) => new Date(a.created_at) - new Date(b.created_at)).pop()?.content || "(Belum ada pesan)";
      const partner = (conv.buyer_id === auth.currentUser.id) ? conv.seller : conv.buyer;
      const userName = partner?.full_name || partner?.email || "Pengguna";
      const lastMessage = conv.messages?.sort((a,b) => new Date(a.created_at) - new Date(b.created_at)).pop();
      const time = lastMessage?.created_at ? new Date(lastMessage.created_at).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) : '';
      const initial = userName[0]?.toUpperCase() || 'U';
      const el = document.createElement("div");
      el.className = "chat-list-item";
      el.innerHTML = `
        <div class="avatar">${initial}</div>
        <div class="chat-list-info">
          <div class="chat-list-name">${escapeHTML(userName)}</div>
          <div class="chat-list-preview">${escapeHTML(lastMsg)}</div>
        </div>
        <div class="chat-list-meta small">${time}</div>
      `;
      el.onclick = () => {
        currentConversationId = conv.id;
        unsubscribeFromChatList();
        main.showPage("chat-detail");
        loadChatMessages(conv.id);
        document.getElementById('chat-detail-header-name').textContent = userName;
        document.getElementById('chat-detail-avatar').textContent = initial;
      };
      container.appendChild(el);
    });
  } catch (err) {
    console.error('loadChatListPage', err);
    container.innerHTML = `<div class="small text-danger">Gagal memuat. (${err.message})</div>`;
  }
}

export async function sendChatMessage(conversation_id, content, receiver_id = null) {
  if (!conversation_id || !auth.currentUser) return main.toast?.("Sesi tidak valid");
  if (!content || typeof content !== 'string' || !content.trim()) {
    return main.toast?.("Pesan kosong");
  }
  try {
    const payload = {
      conversation_id,
      content: content.trim(),
      message_text: content.trim(),
      receiver_id: receiver_id || null,
      sent_at: new Date().toISOString(),
      is_read: false,
      sender_id: auth.currentUser.id
    };
    const { error } = await sb.from("messages").insert([payload]);
    if (error) throw error;
    loadChatMessages(conversation_id);
  } catch (err) {
    console.error("sendChatMessage", err);
    main.toast?.("Gagal kirim pesan: " + (err.message || "Error"));
  }
}

export async function loadChatMessages(conversation_id) {
  const container = document.getElementById('chat-bubbles-container');
  if (!container) return;
  container.innerHTML = '<div class="small">Memuat...</div>';
  try {
    const { data, error } = await sb
      .from('messages')
      .select('content, message_text, sender_id, created_at')
      .eq('conversation_id', conversation_id)
      .order('created_at', { ascending: true });
    if (error) throw error;
    renderChatMessages(data || []);
  } catch (err) {
    console.error('loadChatMessages', err);
    container.innerHTML = '<div class="small">Gagal memuat pesan</div>';
  }
}

function renderChatMessages(list) {
  const container = document.getElementById('chat-bubbles-container');
  if (!container) return;
  container.innerHTML = '';
  if (!list || !list.length) {
    container.innerHTML = '<div class="small" style="text-align:center;">Belum ada pesan</div>';
    return;
  }
  const currentUserId = auth.currentUser?.id;
  list.forEach(m => {
    const isSender = m.sender_id === currentUserId;
    const content = m.content || m.message_text || "";
    const div = document.createElement('div');
    div.className = 'chat-message' + (isSender ? ' sent' : '');
    div.innerHTML = `<div class="msg-text">${escapeHTML(content)}</div>`;
    container.appendChild(div);
  });
  container.scrollTop = container.scrollHeight;
}
