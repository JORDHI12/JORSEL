// supabase.js - reads credentials from import.meta.env (Vite)
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.warn('Supabase URL/Key not set. Please copy .env.example to .env and set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY');
}

export const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export function getStorageUrl(bucketName, filePath) {
  if (!filePath) return '';
  const { data } = sb.storage.from(bucketName).getPublicUrl(filePath);
  return data?.publicUrl || '';
}
export function getProductImageUrl(filePath) { return getStorageUrl('products', filePath); }
export function getAvatarUrl(filePath) { return getStorageUrl('avatars', filePath); }
