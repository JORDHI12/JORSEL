import { sb, getAvatarUrl } from './supabase.js';
import * as auth from './auth.js';
import * as main from './main.js';

let isBalanceHidden = false;

export async function renderProfile(){
  const currentUser = auth.currentUser;
  if(!currentUser){
    document.getElementById('profile_name').textContent='-';
    document.getElementById('profile-email').textContent='-';
    document.getElementById('profile-balance').textContent='Rp0';
    document.getElementById('profile-avatar').textContent='U';
    return;
  }
  try{
    const { data: userData } = await sb.auth.getUser();
    if(userData && userData.user) auth.currentUser = userData.user;
  }catch(e){ console.warn('renderProfile getUser', e); }

  const user = auth.currentUser;
  const metadata = user.user_metadata || {};

  document.getElementById('profile_name').textContent = metadata.full_name || user.email || 'User';
  document.getElementById('profile-email').textContent = user.email || '-';
  const balanceEl = document.getElementById('profile-balance');
  const toggleBtn = document.getElementById('btn-toggle-balance');
  const realBalance = metadata.balance || 0;
  balanceEl.dataset.balance = realBalance;
  if(isBalanceHidden){
    balanceEl.textContent = 'Rp ••••••••';
    toggleBtn.innerHTML = '👁️‍🗨️';
  }else{
    balanceEl.textContent = formatCurrency(realBalance);
    toggleBtn.innerHTML = '👁️';
  }

  const avatarEl = document.getElementById('profile-avatar');
  const fallbackSvg = createFallbackSvg(metadata.full_name || 'U', 60, 24);
  if(metadata.avatar_url){
    const imgUrl = getAvatarUrl(metadata.avatar_url);
    avatarEl.innerHTML = `<img src="${imgUrl}" alt="Avatar" onerror="this.onerror=null; this.src='${fallbackSvg}';" />`;
  } else {
    avatarEl.innerHTML = `<img src='${fallbackSvg}' alt='Avatar'/>`;
  }
}

export function toggleBalanceVisibility(){
  isBalanceHidden = !isBalanceHidden;
  const balanceEl = document.getElementById('profile-balance');
  const toggleBtn = document.getElementById('btn-toggle-balance');
  const realBalance = balanceEl.dataset.balance || 0;
  if(isBalanceHidden){
    balanceEl.textContent = 'Rp ••••••••';
    toggleBtn.innerHTML = '👁️‍🗨️';
  } else {
    balanceEl.textContent = formatCurrency(realBalance);
    toggleBtn.innerHTML = '👁️';
  }
}

export function createFallbackSvg(text, size=100, fontSize=18){
  if(!text) text='??';
  const initials = encodeURIComponent((text.trim().slice(0,2)||'??').toUpperCase());
  const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><rect width="100%" height="100%" fill="#F0EFFF"/><text x="50%" y="50%" font-size="${fontSize}" fill="%235D3A9B" font-family="Arial, sans-serif" text-anchor="middle" dominant-baseline="central">${initials}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgContent)}`;
}

export function formatCurrency(n){ n = Number(n)||0; return 'Rp' + n.toLocaleString('id-ID'); }

export async function uploadAvatar(e){
  if(!auth.currentUser) return main.toast('Login dulu');
  const file = e.target.files[0];
  if(!file) return;
  const avatarEl = document.getElementById('profile-avatar');
  const old = avatarEl.innerHTML;
  avatarEl.innerHTML = '<div style="font-size:24px; line-height:60px;">...</div>';
  try{
    const filename = `public/${auth.currentUser.id}_${Date.now()}.${file.name.split('.').pop()}`;
    const { error: uploadError } = await sb.storage.from('avatars').upload(filename, file, { upsert: true });
    if(uploadError) throw uploadError;
    const { data: updateData, error: updateError } = await sb.auth.updateUser({ data: { avatar_url: filename } });
    if(updateError) throw updateError;
    await renderProfile();
    main.toast('Foto profil berhasil diubah.');
  }catch(err){
    console.error('uploadAvatar', err);
    main.toast('Gagal upload: ' + (err.message || 'Error'));
    avatarEl.innerHTML = old;
  }
}

export function populateAccountDetails(){
  const currentUser = auth.currentUser;
  if(!currentUser) return;
  const metadata = currentUser.user_metadata || {};
  const accTypeEl = document.getElementById('account-type');
  const accNameEl = document.getElementById('account-name');
  const accNumEl = document.getElementById('account-number');
  const withdrawMethodEl = document.getElementById('withdraw-method');
  const withdrawDestEl = document.getElementById('withdraw-destination');
  const accType = metadata.account_type || 'bank';
  const accName = metadata.account_name || '';
  const accNumber = metadata.account_number || '';
  if(accTypeEl){
    accTypeEl.value = accType;
  }
  if(accNameEl && accName) accNameEl.value = accName;
  if(accNumEl) accNumEl.value = accNumber || '';
  if(withdrawMethodEl && withdrawDestEl){
    if(accName && accNumber){
      withdrawMethodEl.value = accName.toUpperCase();
      withdrawDestEl.value = accNumber;
      withdrawMethodEl.disabled = true;
      withdrawDestEl.disabled = true;
    } else {
      withdrawMethodEl.value = '';
      withdrawDestEl.value = '';
      withdrawMethodEl.disabled = false;
      withdrawDestEl.disabled = false;
    }
  }
}
