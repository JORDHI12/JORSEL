import { sb } from './supabase.js';
import * as main from './main.js';

export let currentUser = null;

export async function initAuth(){
  sb.auth.onAuthStateChange((event, session) => {
    if(session && session.user){
      currentUser = session.user;
      postLoginSetup();
    } else {
      currentUser = null;
      onLogout();
    }
  });
  try{
    const { data } = await sb.auth.getUser();
    if(data && data.user) {
      currentUser = data.user;
      postLoginSetup();
    }
  }catch(e){ console.warn('initAuth getUser', e); }
}

export async function signOut(){
  try{
    await sb.auth.signOut();
    currentUser = null;
    onLogout();
    main.toast('Logout berhasil');
  }catch(err){ console.error('signOut', err); main.toast('Gagal logout'); }
}

function onLogout(){
  const elName = document.getElementById('profile_name');
  if(elName) elName.textContent='-';
  main.showPage('auth');
}

async function postLoginSetup(){
  const profile = await import('./profile.js');
  const products = await import('./products.js');
  profile.renderProfile();
  await products.loadHomeProducts();
  await products.loadCategories();
  await products.loadCart();
  main.showPage('home');
}
