import { sb } from './supabase.js';
import * as auth from './auth.js';
import * as main from './main.js';

export function showFinanceTab(tabName){
  document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('tab-content-' + tabName)?.classList.add('active');
  document.getElementById('btn-tab-' + tabName)?.classList.add('active');
}

export async function loadFinancePage(){
  if(!auth.currentUser) return main.showPage('auth');
  const profile = await import('./profile.js');
  profile.populateAccountDetails();
  loadWithdraws();
  loadAffiliateStats();
}

export async function loadWithdraws(){
  const el = document.getElementById('withdraw-list');
  if(!el) return;
  el.innerHTML = '<div class="small">Memuat...</div>';
  try{
    const { data } = await sb.from('withdraws').select('*').eq('user_id', auth.currentUser.id);
    el.innerHTML = (data && data.length) ? data.map(w=>`<div>${w.amount} - ${w.status}</div>`).join('') : '<div class="small">Belum ada penarikan</div>';
  }catch(err){
    console.error('loadWithdraws', err);
    el.innerHTML = '<div class="small">Gagal memuat</div>';
  }
}

export async function loadAffiliateStats(){
  const el = document.getElementById('aff-stats');
  if(!el) return;
  el.textContent = 'Memuat statistik...';
  try{
    const { data } = await sb.from('affiliates').select('*').eq('user_id', auth.currentUser.id);
    el.textContent = (data && data.length) ? 'Total klik: ' + (data.reduce((a,b)=>a+(b.clicks||0),0)) : 'Belum ada aktivitas afiliasi';
  }catch(err){
    console.error('loadAffiliateStats', err);
    el.textContent = 'Gagal memuat statistik';
  }
}

export async function trackAffiliateClick(refId, productId){
  if(!refId) return;
  try{
    const { data: existing } = await sb.from('affiliates').select('*').eq('user_id', refId).eq('product_id', productId).limit(1);
    const payload = { user_id: refId, product_id: productId, last_click_at: new Date().toISOString() };
    if(existing && existing.length){
      const rec = existing[0];
      await sb.from('affiliates').update({ clicks: (rec.clicks||0)+1, ...payload }).eq('id', rec.id);
    } else {
      await sb.from('affiliates').insert([{ clicks: 1, sales: 0, commission_total: 0, created_at: new Date().toISOString(), ...payload }]);
    }
  }catch(err){ console.error('trackAffiliateClick', err); }
}

export function createAffiliateLink(productId){
  const base = location.origin + location.pathname;
  const ref = auth.currentUser?.id;
  if(productId) return `${base}?ref=${encodeURIComponent(ref)}&product=${encodeURIComponent(productId)}`;
  return `${base}?ref=${encodeURIComponent(ref)}`;
}

export async function copyAffiliateLink(){
  const val = document.getElementById('affiliate-link')?.value;
  if(!val) return alert('Login untuk membuat link afiliasi');
  try{ await navigator.clipboard.writeText(val); main.toast('Link afiliasi disalin'); }catch(e){ prompt('Salin manual link afiliasi ini:', val); }
}
