// page.js - lightweight hash-based page router
import { showPage } from './main.js';

const routes = new Set(['home','categories','chat','chat-detail','profile','finance','my-shop','upload-product','bank-account','product-detail','cart','auth','register']);

export function page(name) {
  if(!name) return;
  location.hash = '#' + name;
  // showPage will be triggered by hashchange listener as well, but call once
  try { showPage(name); } catch(e){ console.warn('page showPage', e); }
}

// On hash change, map to showPage
function handleHash() {
  const h = (location.hash || '#home').replace(/^#/,'') || 'home';
  // if route unknown, default to home
  const target = routes.has(h) ? h : 'home';
  showPage(target);
}

window.addEventListener('hashchange', handleHash, false);
// call on initial load
handleHash();
