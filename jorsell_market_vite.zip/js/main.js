// main.js - app bootstrap
import './supabase.js'; // ensure supabase available
import * as auth from './auth.js';
import * as chat from './chat.js';
import * as profile from './profile.js';
import * as products from './products.js';
import * as finance from './finance.js';
import { page } from './page.js';

const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

export function toast(msg, time=2200){
  const el = document.createElement('div'); el.className='toast'; el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(()=> el.remove(), time);
}

export function showPage(id){
  $$('.page').forEach(p=>p.classList.remove('active'));
  const el = document.getElementById(id);
  if(el) el.classList.add('active');
  $$('.nav-item').forEach(n=>n.classList.toggle('active', n.dataset.page===id));

  if(id === 'home') products.loadHomeProducts();
  if(id === 'profile') profile.renderProfile();
  if(id === 'my-shop') products.loadMyProducts();
  if(id === 'finance') finance.loadFinancePage();
  if(id === 'chat') chat.loadChatListPage();
  if(id === 'cart') products.loadCart();
}

document.addEventListener('DOMContentLoaded', async () => {
  // nav clicks -> use page() to update hash
  $$('.nav-item').forEach(n => n.addEventListener('click', () => page(n.dataset.page)));

  // wire some global buttons
  $('#btn-logout')?.addEventListener('click', async () => { await auth.signOut(); page('auth'); });

  $('#btn-send-chat-detail')?.addEventListener('click', async () => {
    const input = document.getElementById('chat-detail-input');
    if(!input) return toast('Input pesan tidak ditemukan');
    const text = (input.value||'').trim();
    if(!text) return toast('Pesan kosong');
    await chat.sendChatMessage(chat.currentConversationId, text);
    input.value = '';
  });
  $('#chat-detail-input')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') $('#btn-send-chat-detail')?.click();
  });

  // initialize auth & load initial data
  await auth.initAuth();
  await products.loadHomeProducts();
  await products.loadCategories();
});
