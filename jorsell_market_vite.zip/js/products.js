import { sb } from './supabase.js';
import * as auth from './auth.js';
import * as main from './main.js';

export async function loadHomeProducts(){
  const elTrending = document.getElementById('trending-products');
  const elLatest = document.getElementById('latest-products');
  if(elTrending) elTrending.innerHTML = '<div class="small">Memuat...</div>';
  if(elLatest) elLatest.innerHTML = '<div class="small">Memuat...</div>';
  try{
    const { data: trending } = await sb.from('products').select('*').order('sales',{ascending:false}).limit(6);
    const { data: latest } = await sb.from('products').select('*').order('created_at',{ascending:false}).limit(6);
    if(elTrending) elTrending.innerHTML = (trending && trending.length) ? trending.map(p => renderProductCard(p)).join('') : '<div class="small">Tidak ada produk</div>';
    if(elLatest) elLatest.innerHTML = (latest && latest.length) ? latest.map(p => renderProductCard(p)).join('') : '<div class="small">Tidak ada produk</div>';
  }catch(err){
    console.error('loadHomeProducts', err);
    if(elTrending) elTrending.innerHTML = '<div class="small">Gagal memuat</div>';
    if(elLatest) elLatest.innerHTML = '<div class="small">Gagal memuat</div>';
  }
}

export async function loadCategories(){
  const el = document.getElementById('home-cats');
  const listEl = document.getElementById('categories-list');
  if(el) el.innerHTML = '<div class="small">Memuat...</div>';
  if(listEl) listEl.innerHTML = '<div class="small">Memuat...</div>';
  try{
    const { data } = await sb.from('categories').select('*');
    if(el) el.innerHTML = (data && data.length) ? data.map(c => `<div class="cat"> <img src="/assets/banner1.png"/> <div>${c.name}</div> </div>`).join('') : '<div class="small">Tidak ada kategori</div>';
    if(listEl) listEl.innerHTML = (data && data.length) ? data.map(c => `<div style="padding:8px;border:1px solid #eee;border-radius:8px">${c.name}</div>`).join('') : '<div class="small">Tidak ada kategori</div>';
  }catch(err){
    console.error('loadCategories', err);
    if(el) el.innerHTML = '<div class="small">Gagal memuat</div>';
  }
}

function renderProductCard(p){
  const title = p.title || p.name || 'Produk';
  const price = p.price ? 'Rp' + Number(p.price).toLocaleString('id-ID') : 'Rp0';
  return `<div class="product" data-id="${p.id}">
    <div class="p-thumb"><img src="/assets/banner1.png" alt="thumb"/></div>
    <div class="p-title">${title}</div>
    <div class="p-meta">${price}</div>
    <div style="display:flex;gap:8px;margin-top:8px">
      <button class="btn" onclick="location.hash='product-'+${p.id}">Detail</button>
      <button class="btn-outline" onclick="addToCart(${p.id})">Tambah</button>
    </div>
  </div>`;
}

export async function loadCart(){
  const el = document.getElementById('cart-list');
  if(!el) return;
  el.innerHTML = '<div class="small">Memuat keranjang...</div>';
  try{
    if(!auth.currentUser) { el.innerHTML = '<div class="small">Login untuk melihat keranjang</div>'; return; }
    const { data } = await sb.from('carts').select('product_id,qty,products(*)').eq('user_id', auth.currentUser.id);
    if(!data || !data.length) { el.innerHTML = '<div class="small">Keranjang kosong</div>'; document.getElementById('cart-count').textContent = '0'; document.getElementById('cart-total').textContent='Rp0'; return; }
    const rows = data.map(i=>`<div style="display:flex;justify-content:space-between;padding:8px 0">${i.products?.name||i.product_id} <strong>Rp${(i.products?.price||0).toLocaleString('id-ID')}</strong></div>`).join('');
    el.innerHTML = rows;
    document.getElementById('cart-count').textContent = data.length;
    const total = data.reduce((a,b)=>a + (b.products?.price||0)*b.qty, 0);
    document.getElementById('cart-total').textContent = 'Rp' + total.toLocaleString('id-ID');
  }catch(err){
    console.error('loadCart', err);
    el.innerHTML = '<div class="small">Gagal memuat keranjang</div>';
  }
}

export async function checkout(){
  if(!auth.currentUser) return main.toast('Login dulu');
  try{
    const { data: items } = await sb.from('carts').select('product_id, qty, products(price)').eq('user_id', auth.currentUser.id);
    if(!items || !items.length) { main.toast('Keranjang kosong atau error'); return; }
    const total = items.reduce((a,b)=> a + (b.products?.price || 0) * b.qty, 0);
    const { data: order } = await sb.from('orders').insert([{ user_id: auth.currentUser.id, total }]).select().single();
    const orderItems = items.map(i=> ({ order_id: order.id, product_id: i.product_id, price: i.products.price, quantity: i.qty }));
    await sb.from('order-items').insert(orderItems);
    await sb.from('carts').delete().eq('user_id', auth.currentUser.id);
    main.toast('Checkout berhasil 🎉. Order ID: ' + order.id);
    loadCart();
  }catch(err){
    console.error('checkout', err);
    main.toast('Gagal checkout');
  }
}

window.addToCart = async function addToCart(productId){
  if(!auth.currentUser) { return main.toast('Login dulu'); }
  try{
    await sb.from('carts').insert([{ user_id: auth.currentUser.id, product_id: productId, qty: 1 }]);
    main.toast('Produk ditambahkan ke keranjang');
    loadCart();
  }catch(err){ console.error('addToCart', err); main.toast('Gagal tambah'); }
};
